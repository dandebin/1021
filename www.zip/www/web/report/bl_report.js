app.controller('reportCtr', function($scope, service, $rootScope){
	var type=$rootScope.param('type')||1;
	var titledic=['title', 'Top 10 restauant', 
	'Total pays per month', 
	'Total pays per restauant',
	'Total amount per restauant',
	'Total amount per acount/people'
	 ];

	 var actiondic=['', 'GetPaysCountPerMonth', 'GetPaysCountPerRestaurant', 'GetTotalAmountPerRestaurant', 'GetTotalAmountEveryPeople', 'GetTotalAmountPerRestaurant'];

	 var title=titledic[type];
	 var action='OrderService.asmx/'+actiondic[type];

	//google.load("visualization", "1", {packages:["corechart"]});
	//google.setOnLoadCallback(drawChart);
	function drawChart() {
		service.invokePost(action, 
			{}, 
			function(result){
				var d= $.parseJSON($(result).find('string').text());
                         	 //params.total(data.Total);
                            // $defer.resolve(d);
				onDraw(d, 'transactionHistory')
		});
	}

	function onDraw(jsonData, id){
		var data = new google.visualization.DataTable();
		data.addColumn('string', 'Month');
		data.addColumn('number', 'Value');
		$.map(jsonData, function(key, val){
			data.addRow([key.Name, key.Value]);
		});
		var options = {
			"title": title,
			"vAxis":{"title":"Value", showTextEvery:1},
  			"hAxis":{"title":"Name",showTextEvery:1},
		};
		var chart = new google.visualization.LineChart(document.getElementById(id));
		chart.draw(data, options);
	}

	$scope.init=function(){
		drawChart();
	}
	
	$scope.init();
});

app.controller('top10Ctr', function($scope, service, $rootScope){
	service.invokePost('StoreService.asmx/Top10FavoriteStores', 
			{}, 
			function(result){
				var d= $.parseJSON($(result).find('string').text());
                         	 //params.total(data.Total);
                            // $defer.resolve(d);
				$scope.data=d;
		});

	
});
