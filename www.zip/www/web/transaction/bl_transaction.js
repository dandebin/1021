//var app=angular.module('app', ['ngRoute', 'ngResource', 'ngTable', 'ngTableExport']); //'ui.bootstrap'

app.controller('transactionHistoryCtr', function ($scope, service, $filter, ngTableParams, $translate) {
	var data=[];
	$scope.merchants=[];
	$scope.td={};

    $scope.init=function(){
     	$scope.tableParams = new ngTableParams({
	        page: 1,            // show first page
	        count: 10,          // count per page
	        sorting: {
	            OrderDateTime: 'desc'     // initial sorting
	        }
	    }, {
	        total: 0, // length of data
	        getData: function($defer, params) {
	           service.invokePost('OrderService.asmx/GetOrders', {
	           				userId: $scope.userId || '',
							pageIndex:params.page(),
							pageSize: params.count(),
							Sort: params.sorting()
					}, 
					function(result){
						var d= $.parseJSON($(result).find('string').text());
						$defer.resolve(d);
				});
	        }
	    });
    }

	$scope.onQueryHistory=function(){
		$scope.tableParams.page(1);
		$scope.tableParams.reload(); 
	}

	$scope.onClickDetail=function(item){
		service.GetTransactionDetail({orderId: item.OrderId},function(result){
			if(result.IsSuccess){
				$scope.td=result.Results.Data;
				$('#myModal').modal('show');
			}
			
		});
	}

	$scope.init();
});


app.controller('transactionRiskCtr', function ($scope, service, $filter, ngTableParams, $translate) {
	var data=[];
	$scope.merchants=[];
	$scope.td={};

    $scope.init=function(){
     	$scope.tableParams = new ngTableParams({
	        page: 1,            // show first page
	        count: 10,          // count per page
	        sorting: {
	            OrderDateTime: 'desc'     // initial sorting
	        }
	    }, {
	        total: 0, // length of data
	        getData: function($defer, params) {
	           service.invokePost('OrderService.asmx/GetRiskAccount', {
	           				acceptanceCount: $scope.acceptanceCount || '0',
							pageIndex:params.page(),
							pageSize: params.count(),
							Sort: params.sorting()
					}, 
					function(result){
						var d= $.parseJSON($(result).find('string').text());
						$defer.resolve(d);
				});
	        }
	    });
    }

	$scope.onQuery=function(){
		$scope.tableParams.page(1);
		$scope.tableParams.reload(); 
	}

	$scope.onClickDetail=function(item){
		service.GetTransactionDetail({orderId: item.OrderId},function(result){
			if(result.IsSuccess){
				$scope.td=result.Results.Data;
				$('#myModal').modal('show');
			}
			
		});
	}

	$scope.init();
});