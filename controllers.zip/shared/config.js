URL_DEV = 'http://localhost:1779/';
URL_ITG = 'http://112.64.131.222/weishop.service/api/';

app.constant('config', {
    serviceUrl: URL_DEV,
    weixinProxy: 'http://112.64.131.222/weishop.weixin/'
});

app.config(['$compileProvider', function ($compileProvider) {
    $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|#|chrome-extension):/);
    // Angular before v1.2 uses $compileProvider.urlSanitizationWhitelist(...)
}]);

$.ajaxSetup({
    beforeSend: function (request) {
        var user = window.localStorage.getItem('userInfo') || {};
        try {
            var wxChars = window.localStorage.getItem('WeixinId') || "";
            request.setRequestHeader('wxChars', wxChars);
            var token = $.parseJSON(user).userToken || '';
            request.setRequestHeader('Token', token);
            request.setRequestHeader('Lang', window.localStorage.lang);
        } catch (e) {
        }
        $('#loading').show();
        //$('#loading').show();
    },
    complete: function (request, status) {
    }
});