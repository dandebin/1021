var app=angular.module('app');
app.service('service', function($http, config, $q){
		this.url=config.serviceUrl;
		var deferred = $q.defer();

		this.invokeGet=function(action, data, then){
			var deferred = $q.defer();
			$.get(this.url+ action, data)
			.success(function(data){
				deferred.resolve(data);
				deferred.promise.then(then(data));
			});
		}

		this.invokePost=function(action, data, then){
			var deferred = $q.defer();
			$.post(this.url+ action, data)
			.success(function(data){
				deferred.resolve(data);
				deferred.promise.then(then(data));
			});
		}

		this.saveUserInLocale=function(user){
			window.localStorage.setItem('userInfo', JSON.stringify(user));
		}

		this.getUserFromLocale=function(){
			var user = window.localStorage.getItem('userInfo');
			return $.parseJSON(user);
		}
        
		this.toindexPage = function () {
		    window.location.href = 'index.html#/metro';
		    return false;
		}

		this.padUser = function (data, then) {
		    $.post(this.url + 'customer/query', data).success(function (data) {
		        deferred.resolve(data);
		        deferred.promise.then(then(data));
		    });
		}

		this.removeUserFromLocale=function(){
			window.localStorage.setItem('userInfo', '');
		}

		this.getExchangeRate=function(data, then){
			//$.post(this.url+'Transaction/GetTransactionDetail', data, then);
			
			$.post(this.url+'ExchangeRate/GetExchangeRate', data)
			.success(function(data){
				deferred.resolve(data);
				deferred.promise.then(then(data));
			});
		
		}
});