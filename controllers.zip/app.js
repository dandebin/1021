var app=angular.module('app', ['ngRoute']);

app.config(function($routeProvider){
	$routeProvider
	.when('/main',{
		templateUrl:'views/main.html',
		controller: 'mainController'
	})
	.when('/metro',{
		templateUrl:'views/metro.html',
		controller: 'metroController'
	})
	.when('/my',{
		templateUrl:'views/my.html',
		controller: 'myController'
	})
	.when('/coupon',{
		templateUrl:'views/coupon.html',
		controller: 'couponController'
	})
	.when('/order',{
		templateUrl:'views/order.html',
		controller: 'orderController'
	})
	.when('/welfare',{
		templateUrl:'views/welfare.html',
		controller: 'welfareController'
	})
	.when('/pay',{
		templateUrl:'views/pay.html',
		controller: 'payController'
	})
	.when('/payscan',{
		templateUrl:'views/payscan.html',
		controller: 'payscanController'
	})
	.otherwise({
		redirectTo:'/metro'
	});
});

app.controller('rootController', function($scope){
	$scope.showmetro=false;
});
