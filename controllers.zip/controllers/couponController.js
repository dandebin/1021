var app=angular.module('app');
app.controller('couponController', function($scope, service, config){
	$scope.id='1234567890';
	$scope.wxChars=window.localStorage.getItem('WeixinId');
	$scope.weixinProxy=config.weixinProxy;
	$scope.onGetCoupons=function(state){
		$scope.coupons=[{
			CouponCode:'111',
			EntryDate:'2016-01-01',
			ExpireDate:'2016-12-30',
			Path:'imgs/coupon/75.jpg',
			UseArea:'有效期至:2016-12-30'
		}];
	    service.invokePost('coupon/customercouponst', {state:state},			
			function(result){
				$scope.safeApply(function(){
					if(result.IsSuccess && result.Results.Data!=null){
						$scope.coupons=result.Results.Data;
						//for testing
						//for(i=0;i<$scope.coupons.length;++i){
						//	$scope.coupons[i].Path='imgs/coupon/75.jpg';
						//}
					}else{
						$scope.coupons=[];
					}
					
				});		
		});
	}

	$scope.onGetCoupons(1);
});