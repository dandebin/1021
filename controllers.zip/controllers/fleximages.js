var app=angular.module('app');
app.controller('metroController', function($scope){
	$('#fleximgs').flexImages({rowHeight: 140});
});