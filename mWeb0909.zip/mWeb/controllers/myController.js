var app = angular.module('app');
app.controller('myController', function ($scope, service, $rootScope) {
    $scope.title = 'my';
    $scope.user = {};
    $scope.userExists = false;
    $scope.init = function () {
        var linkOpenId = $scope.param('WeixinId')
        if (!$scope.isNullOrEmpty(linkOpenId)) {
            window.localStorage.setItem('WeixinId', linkOpenId);
        }

        $scope.user.WeixinId = window.localStorage.getItem('WeixinId');

        jQuery(".form_datetime").datetimepicker({ pickDate: true, minView: "month", format: 'yyyy-mm-dd', language: 'zh-CN', autoclose: true, forceParse: false, maskInput: true }).on("keydown", function () {
            jQuery(this).datetimepicker('show');
        }).on("touchstart", function () { jQuery(this).datetimepicker('show'); });
    }

    $scope.onSubmit = function () {
        service.invokePost('UserService.asmx/Register', 
        {
            name: $scope.user.Name,
            email: $scope.user.Email,
            type:0,
            phone: $scope.user.PhoneNo,
            birthday: $scope.user.Birthday
        },function(result){
            if('true'==$(result).find('boolean').text()){
                alert('提交成功');
            }else{
                alert('操作失败，请稍后重试');
            }
             
        });
    }

    $scope.init();
});