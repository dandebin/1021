var app = angular.module('app');
app.controller('payController', function ($scope, service, $rootScope) {
    $scope.title = 'my';
    $scope.order={};

    $scope.$watch(function(scope) { return scope.order.amount },
              function(newValue, oldValue) {
                 $scope.order.amount2=$scope.order.discount*$scope.order.amount;
              }
             );

    $scope.init = function () {
       //var discount= $rootScope.param('discount');
       $scope.order.amount=10;
       $scope.order.discount=$rootScope.param('discount')||0.9;

    }

    $scope.onSubmit = function () {
        var id= $rootScope.param('id')||1;
        window.location.hash='#/payscan'+'?id='+id+'&amount='+$scope.order.amount2;
       
    }

    $scope.init();
});

app.controller('payscanController', function ($scope, service, $rootScope, config) {
    $scope.title = 'my';

    $scope.code='';
    $scope.init = function () {
        var id= $rootScope.param('id')||1;
        var amount=$rootScope.param('amount');
        var wcharid=window.localStorage.getItem('WeixinId')||'1';
       $scope.code=config.serviceUrl+'ScanResult.aspx?p='+id
        +'/'+wcharid+'/'+amount+'/abc28521dee731b84a77f7c3a3a727ff';
    }

    $scope.init();
});
