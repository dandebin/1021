var app = angular.module('app');
app.controller('orderController', function ($scope, service, $rootScope) {
    $scope.title = 'my';
    $scope.user = {};
    $scope.userExists = false;
    $scope.order = {};

    $scope.init = function () {
        $(".form_datetime").datetimepicker({ format: 'yyyy-mm-dd hh:ii' });
        var date = new Date().dateAdd('h', 0.6);
        var time = date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + ' '
			+ date.getHours() + ':' + date.getMinutes();
        //$scope.order.wxChars=window.localStorage.getItem('WeixinId');
        //wxchars get from request header
        $scope.order.dt = time;
        if ($rootScope.userInfo === undefined) {
            $rootScope.userInfo = service.getUserFromLocale();
        }
        $scope.order.contact = ($rootScope.userInfo || {}).PhoneNo || '';
    }

    $scope.onSubmit = function () {
        service.invokePost('dining/add',
			$scope.order,
			function (result) {
			    if (result.IsSuccess) {
			        $scope.userExists = true;
			        $scope.safeApply(function () {
			            alert('订餐已成功，Inghouse恭迎您的光临！');
			        });
			    } else {
			        alert(result.ErrorMessage);
			    }
			});
    }

    $scope.init();
});