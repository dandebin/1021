﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Entities;
using Newtonsoft.Json;

namespace Restaurant
{
    /// <summary>
    /// OrderService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class OrderService : System.Web.Services.WebService
    {
        [WebMethod]
        public bool AddOrder(int userId,int storeId, decimal discount, decimal amount)
        {
            return new OrderEntity().InsertOrder(userId, storeId, discount, amount);
        }

        [WebMethod]
        public bool DeleteOrder(int orderId)
        {
            return new OrderEntity().DeleteOrder(orderId);
        }

        [WebMethod]
        public string GetOrders(string userId,int pageIndex=1, int pageSize=10)
        {
            return JsonConvert.SerializeObject(new OrderEntity().GetOrders(userId, pageIndex, pageSize));
        }

        [WebMethod]
        public string GetTotalAmountEveryPeople()
        {
           return JsonConvert.SerializeObject(new OrderEntity().GetTotalAmountEveryPeople());
        }

        [WebMethod]
        public string GetTotalAmountPerRestaurant()
        {
            return JsonConvert.SerializeObject(new OrderEntity().GetTotalAmountPerRestaurant());
        }

        [WebMethod]
        public string GetPaysCountPerRestaurant()
        {
           return JsonConvert.SerializeObject(new OrderEntity().GetPaysCountPerRestaurant());
        }

        [WebMethod]
        public string GetPaysCountPerMonth()
        {
            return JsonConvert.SerializeObject(new OrderEntity().GetPaysCountPerMonth());
        }
    }
}
