﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Entities;
using Newtonsoft.Json;

namespace Restaurant
{
    /// <summary>
    /// StoreService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class StoreService : System.Web.Services.WebService
    {
        [WebMethod]
        public string GetStores(string storeName,int pageIndex,int pageSize)
        {
            return JsonConvert.SerializeObject(new StoreEntity().GetAllStores(storeName, pageIndex, pageSize));
        }

        [WebMethod]
        public bool RegisterStore(string storeName)
        {
            return new StoreEntity().RegisterStore(storeName);
        }

        [WebMethod]
        public bool UpdateStoreStatus(int storeId, bool status)
        {
            return new StoreEntity().UpdateStore(new StoreInfo() { StoreId = storeId, Status = status });
        }

        [WebMethod]
        public string Top10FavoriteStores()
        {
            return JsonConvert.SerializeObject(new OrderEntity().GetTop10FavoriteRestaurant());
        }

        [WebMethod]
        public bool PayScan(string storeid, string wecharid, float amount)
        {
           UserInfo userInfo = new UserEntity().GetUserViaWechartId(wecharid);
           return new OrderEntity().InsertOrder(userInfo.UserId,Convert.ToInt16(storeid), 0, Convert.ToDecimal(amount));
        }
    }
}
