﻿using Entities;
using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Newtonsoft.Json;

namespace Restaurant
{
    /// <summary>
    /// UserService 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // 若要允许使用 ASP.NET AJAX 从脚本中调用此 Web 服务，请取消注释以下行。 
    // [System.Web.Script.Services.ScriptService]
    public class UserService : System.Web.Services.WebService
    {
        [WebMethod]
        public bool Register(string name,string pwd, string email, string phoneNumber,int typeId)
        {
            new UserEntity().RegisterUser(new UserInfo()
            {
                 UserName=name, Password=pwd, Email=email, PhoneNumber="",TypeId=typeId
            });

            //1.Send Active email
            return true;
        }

        [WebMethod]
        public bool Login(string name, string password)
        {
           return new UserEntity().Login(name, password);
        }

        [WebMethod]
        public bool ActiveUser(string name)
        {
            return new UserEntity().ActiveUser(name);
        }

        [WebMethod]
        public string GetUser(string name,int pageIndex=1,int pageSize=10)
        {
            return JsonConvert.SerializeObject(new UserEntity().GetUserViaName(name, pageIndex,pageSize));
        }
    }
}
