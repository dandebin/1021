﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Models;

namespace Entities
{
    public class OrderEntity
    {
        public bool InsertOrder(int userId, int storeId, decimal discount, decimal amount)
        {
            using (var db = new SwingDataContext())
            {
                db.Orders.InsertOnSubmit(new Order() { 
                    UserID=userId,
                    StoreID=storeId,
                    Discount=discount,
                    Amount=amount
                });
            }
            return true;
        }

        public bool DeleteOrder(int orderId)
        {
            using (var db = new SwingDataContext())
            {
                var order = (from o in db.Orders
                             where o.OrderID == orderId
                             select o).First();
                db.Orders.DeleteOnSubmit(order);
                db.SubmitChanges();
            }
            return true;
        }

        public List<OrderInfo> GetOrders(string userId,int pageIndex=1, int pageSize=10)
        {
            List<OrderInfo> orderList = new List<OrderInfo>();
            using (var db = new SwingDataContext())
            {
                var allOrder = from o in db.Orders
                              select FillStoreInfo(o);
                if (string.IsNullOrEmpty(userId))
                {
                    return allOrder.Where(x => x.UserId == Convert.ToInt16(userId)).ToList();
                }
                return allOrder.Skip(pageIndex*pageSize).Take(pageSize).ToList();
            }
            return orderList;
        }

        public List<ReportItem> GetPaysCountPerMonth()
        {
            //Dictionary<int, int> dic = new Dictionary<int, int>();
            using (var db = new SwingDataContext())
            {
               var dic = (from o in db.Orders
                       group o by o.CreateDate.Value.Month into g
                          select new ReportItem
                       {
                           Name = g.Key.ToString(),
                           Value = g.Count()
                       });
               return dic.ToList();
            }
            
        }

        public List<ReportItem> GetPaysCountPerRestaurant()
        {
            using (var db = new SwingDataContext())
            {
                var dic = (from o in db.Orders
                           group o by o.StoreID.Value into g
                           select new ReportItem
                           {
                               Name = g.Key.ToString(),
                               Value = g.Count()
                           });
                return dic.ToList();
            }
        }

        public List<ReportItem> GetTotalAmountPerRestaurant()
        {
            using (var db = new SwingDataContext())
            {
                var dic = (from o in db.Orders
                       group o by o.StoreID.Value into g
                       select new ReportItem
                           {
                               Name = g.Key.ToString(),
                               Value = g.Count()
                           });
                return dic.ToList();
            }
        }

        public List<ReportItem> GetTotalAmountEveryPeople()
        {
            using (var db = new SwingDataContext())
            {
                var dic = (from o in db.Orders
                       group o by o.UserID.Value into g
                       select new ReportItem
                           {
                               Name = g.Key.ToString(),
                               Value = g.Count()
                           });
                return dic.ToList();
            }
        }

        public List<StoreInfo> GetTop10FavoriteRestaurant()
        {
            List<StoreInfo> top10Stores = new List<StoreInfo>();
            StoreEntity entity = new StoreEntity();
            var dic = GetPaysCountPerRestaurant().OrderByDescending(x => x.Value).Take(10);
            foreach (var item in dic)
            {
                StoreInfo store = entity.GetStoreViaId(Convert.ToInt16(item.Name));
                top10Stores.Add(store);
            }
            return top10Stores;
        }

        private OrderInfo FillStoreInfo(Order o)
        {
            OrderInfo info = new OrderInfo();
            info.OrderId = (int)o.OrderID;
            info.UserId = (int)o.UserID;
            info.StoreId = (int)o.StoreID;
            info.Discount = (int)o.Discount;
            info.Amount = o.Amount.Value;
            info.CreateDate = o.CreateDate.Value;
            return info;
        }
    }
}
