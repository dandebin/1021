﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Models;

namespace Entities
{
    public class StoreEntity
    {
        public StoreInfo GetStoreViaName(string storeName)
        {
            StoreInfo storeInfo = null;
            using (var db = new SwingDataContext())
            {
                var store = (from t in db.Stores
                             where t.StoreName == storeName
                             select t).First();
                if (store != null)
                {
                    
                }
            }
            return storeInfo;
        }

        public List<StoreInfo> GetAllStores(string storeName, int pageIndex = 1, int pageSize = 10)
        {
            List<StoreInfo> storeList = new List<StoreInfo>();
            using (var db = new SwingDataContext())
            {
                var allstore = from o in db.Stores
                               select FillStoreInfo(o);
                if (allstore.Count() != 0)
                {
                    return allstore.Where(x => x.StoreName == storeName).ToList();
                }
                return allstore.Skip(pageIndex * pageSize).Take(pageSize).ToList();
            }


            using (var db = new SwingDataContext())
            {
                var stores = from t in db.Stores
                             where t.Status == 1
                             select t;

                foreach (var store in stores)
                {
                    StoreInfo storeInfo = new StoreInfo();
                    storeInfo = new StoreInfo();
                    storeInfo.StoreId = store.StoreID;
                    storeInfo.StoreName = store.StoreName;
                    storeInfo.Status = store.Status == 1 ? true : false;
                    storeInfo.CreateDate = store.CreateDate.Value;
                    storeInfo.Discount = Convert.ToDecimal(0.9);
                    storeList.Add(storeInfo);
                }
            }
            return storeList;
        }

        public bool RegisterStore(string storeName)
        {
            using (var db = new SwingDataContext())
            {
                db.Stores.InsertOnSubmit(new Store() {
                    StoreName = storeName,
                    Status=0
                });
                db.SubmitChanges();
            }
            return true;
        }

        public bool UpdateStore(StoreInfo storeInfo)
        {
            using (var db = new SwingDataContext())
            {
                var store = (from t in db.Stores
                             where t.StoreID == storeInfo.StoreId
                             select t).First();
                store.StoreName = storeInfo.StoreName;
                store.Status = storeInfo.Status?1:0;
                store.CreateDate = DateTime.Now;
                db.SubmitChanges();
            }
            return true;
        }

        public bool DeleteStore(string storeName)
        {
            using (var db = new SwingDataContext())
            {
                var store = (from t in db.Stores
                             where t.StoreName == storeName
                             select t).First();
                db.Stores.DeleteOnSubmit(store);
                db.SubmitChanges();
            }
            return true;
        }

        public bool ActivateStore(string storeName)
        {
            using (var db = new SwingDataContext())
            {
                var store = (from t in db.Stores
                             where t.StoreName == storeName
                             select t).First();
                store.Status = 1;
                db.SubmitChanges();
            }
            return true;
        }

        public StoreInfo GetStoreViaId(int storeId)
        {
            StoreInfo storeInfo = null;
            using (var db = new SwingDataContext())
            {
                var store = (from t in db.Stores
                             where t.StoreID == storeId
                             select t).First();
                if (store != null)
                {
                    storeInfo = new StoreInfo();
                    storeInfo.StoreId = store.StoreID;
                    storeInfo.StoreName = store.StoreName;
                    storeInfo.Status = store.Status == 1 ? true : false;
                    storeInfo.CreateDate = store.CreateDate.Value;
                }
            }
            return storeInfo;
        }

        private StoreInfo FillStoreInfo(Store store) {
            StoreInfo storeInfo = new StoreInfo();
            storeInfo.StoreId = store.StoreID;
            storeInfo.StoreName = store.StoreName;
            storeInfo.Status = store.Status == 1 ? true : false;
            storeInfo.CreateDate = store.CreateDate.Value;
            return storeInfo;
        }
    }
}
