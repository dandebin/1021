﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Models;

namespace Entities
{
    public class DiscountEntity
    {
        public bool InsertDiscount(int storeId,decimal discount)
        {
            using (var db = new SwingDataContext())
            {
                db.Discounts.InsertOnSubmit(new Discount() { 
                    StoreID=storeId,
                    Discount1=discount
                });
                db.SubmitChanges();
            }
            return true;
        }

        public bool UpdateDiscount(DiscountInfo discountInfo)
        {
            using (var db = new SwingDataContext())
            {
                var discount = (from d in db.Discounts
                                where d.StoreID == discountInfo.StoreId
                                select d).First();
                discount.StoreID = discountInfo.StoreId;
                discount.Discount1 = discountInfo.Discount;
                discount.CreateDate = DateTime.Now;
                db.SubmitChanges();
            }
            return true;
        }

        public bool DeleteDiscount(int storeId)
        {
            using (var db = new SwingDataContext())
            {
                var discount = (from d in db.Discounts
                             where d.StoreID == storeId
                                select d).First();
                db.Discounts.DeleteOnSubmit(discount);
                db.SubmitChanges();
            }
            return true;
        }

        public DiscountInfo GetDiscount(int storeId)
        {
            using (var db = new SwingDataContext())
            {
                var ds = (from d in db.Discounts
                             where d.StoreID==storeId
                             select d).First();
                DiscountInfo info = new DiscountInfo();
                info.DiscountId = ds.DiscountID;
                info.StoreId = ds.StoreID.Value;
                info.Discount = ds.Discount1.Value;
                return info;
            }
        }
    }
}
