﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entities
{
    public class UserEntity
    {
        public bool RegisterUser(UserInfo user)
        {
            using (var db = new SwingDataContext())
            {
                db.Users.InsertOnSubmit(new User()
                {
                    UserName = user.UserName,
                    Password=user.Password,
                    Email = user.Email,
                    Status = false,
                    TypeID = user.TypeId,
                });
                db.SubmitChanges();
            }
            return true;
        }

        public bool Login(string userName,string password)
        {
            using (var db = new SwingDataContext())
            {
                var q = from u in db.Users
                        where u.UserName == userName && u.Password==password
                        select u;
                return q.Count() == 1;
            }
        }

        public bool ActiveUser(string userName)
        {
            using (var db = new SwingDataContext())
            {
                var r = (from u in db.Users
                        where u.UserName == userName
                        select u).First();
                r.Status = true;
                db.SubmitChanges();
            }
            return true;
        }

        public bool UpdateUser(UserInfo user)
        {
            using (var db = new SwingDataContext())
            {
                var r = (from u in db.Users
                        where u.UserName == user.UserName
                        select u).First();
                r.Password = user.Password;
                r.Email = user.Email;
                r.Status = user.Status;
                r.TypeID = user.TypeId;
                r.PhoneNumber = user.PhoneNumber;
                r.CreateDate = DateTime.Now;
                db.SubmitChanges();
            }
            return true;
        }

        public List<UserInfo> GetUserViaName(string name,int pageIndex=1, int pageSize=10)
        {
            List<UserInfo> userList = new List<UserInfo>();
            using (var db = new SwingDataContext())
            {
                var allUser = from u in db.Users
                              select FillUserInfo(u);
                if (allUser.Count()!=0)
                {
                    return allUser.Where(x => x.UserName == name).ToList();
                }
                return allUser.Skip(pageIndex * pageSize).Take(pageSize).ToList();
            }
        }

        public UserInfo GetUserViaWechartId(string wechartId)
        {
            UserInfo userInfo = null;
            using (var db = new SwingDataContext())
            {
                var user = (from u in db.Users
                        where u.WechartID==wechartId
                        select u).First();
                if (user != null)
                {
                    userInfo = new UserInfo();
                    userInfo.UserId = user.UserID;
                    userInfo.WechartId = wechartId;
                    userInfo.UserName = user.UserName;
                    userInfo.Password = user.Password;
                    userInfo.Email = user.Email;
                    userInfo.Status = user.Status.Value;
                    userInfo.TypeId = user.TypeID.Value;
                    userInfo.PhoneNumber = user.PhoneNumber;
                    userInfo.CreateDate = DateTime.Now;
                }
            }
            return userInfo;

        }

        private UserInfo FillUserInfo(User user)
        {
            UserInfo userInfo = new UserInfo();
            userInfo.UserId = user.UserID;
            userInfo.WechartId = user.WechartID;
            userInfo.UserName = user.UserName;
            userInfo.Password = user.Password;
            userInfo.Email = user.Email;
            userInfo.Status = user.Status.Value;
            userInfo.TypeId = user.TypeID.Value;
            userInfo.PhoneNumber = user.PhoneNumber;
            userInfo.CreateDate = DateTime.Now;
            return userInfo;
        }
    }
}
