﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Models
{
    public  class StoreInfo
    {
        public int StoreId { get; set; }
        public string StoreName { get; set; }
        public decimal Discount { get; set; }
        public bool Status { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
