﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Models
{
    public class DiscountInfo
    {
        public int DiscountId { get; set; }
        public int StoreId { get; set; }
        public decimal Discount { get; set; }
        public DateTime CreateDate { get; set; }
    }
}
