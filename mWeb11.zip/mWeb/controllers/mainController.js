var app=angular.module('app');
app.controller('mainController', function($scope){
	$scope.id='1234567890';
});