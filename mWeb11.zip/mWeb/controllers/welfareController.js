var app=angular.module('app');
app.controller('welfareController', function($scope){
	$scope.title='我的特权';
});