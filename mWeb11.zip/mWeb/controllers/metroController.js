var app=angular.module('app');
app.controller('metroController', function ($scope, service, $rootScope) {
	$scope.coupons=[
		{src:'imgs/coupon/201.jpg', cls:'item active'},
		{src:'imgs/coupon/202.jpg', cls:'item'},
		{src:'imgs/coupon/203.jpg', cls:'item'} 
	];
	$scope.features=[
		{src: 'imgs/menu/order.png',url:'#/order'},
		{src: 'imgs/menu/my.png',url:'#/my'},
		{src: 'imgs/menu/myown.png',url:'#/welfare'},
		{src: 'imgs/menu/coupon.png',url:'#/coupon'},
	];
	$scope.menus=[
		{src: 'imgs/menu/4.png',url:'index.html#/pay', w:188, h: 156},
		{src: 'imgs/menu/5.png',url:'index.html#/pay', w:282, h: 156},
		{src: 'imgs/menu/6.png',url:'index.html#/pay', w:201, h: 156},
		{src: 'imgs/menu/7.png',url:'index.html#/pay', w:269, h: 156},
	];
	$scope.init = function () {	   
		service.invokePost('StoreService.asmx/GetStores', 
        {
           
        },function(result){
        	//$scope.menus=[];
            $(result).find('StoreInfo').each(
            	function(i){
            		var menu=$scope.menus[i]||{};
            		menu.id= $(this).find('Id').text();
            		menu.discount= $(this).find('Discount').text();
            		menu.url='index.html#/pay?id='+menu.id+'&discount='+menu.discount;
            });
        })


	    setTimeout(function () {
	        try {
	            $('#metroitems').flexImages({ rowHeight: 140, truncate: 1 });
	        } catch (e) {

	        }
	    }, 100);
	    service.padUser({}, function (data) {
	        if (data) {	          
	            $scope.safeApply(function () {
	                service.saveUserInLocale(data.Results);
	                $rootScope.userInfo = data.Results;
	            });
	        }
	    });
	};	
	
	$scope.init();
});