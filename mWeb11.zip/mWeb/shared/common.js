var app=angular.module('app');
app.run(function($rootScope){

	$rootScope.safeApply = function(fn) {
		  var phase = this.$root.$$phase;
		  if(phase == '$apply' || phase == '$digest') {
		    if(fn && (typeof(fn) === 'function')) {
		      fn();
		    }
		  } else {
		    this.$apply(fn);
		  }
	};

	$rootScope.param=function(name) {
	  var regexS = "[\\?&]"+name+"=([^&#]*)", 
	  regex = new RegExp( regexS ),
	  results = regex.exec( window.location.hash);
	  if( results == null ){
	    return "";
	  } else{
	    return decodeURIComponent(results[1].replace(/\+/g, " "));
	  }
	}

	$rootScope.isNullOrEmpty=function(value) {
	  return value==undefined || value==null || value=='' || value=="";
	}
});

Date.prototype.dateAdd = function(strInterval, Number) {     
  
    var dtTmp = this;    
  
    switch (strInterval) {     
  
        case 's' :return new Date(Date.parse(dtTmp) + (1000 * Number));    
  
        case 'n' :return new Date(Date.parse(dtTmp) + (60000 * Number));    
  
        case 'h' :return new Date(Date.parse(dtTmp) + (3600000 * Number));    
  
        case 'd' :return new Date(Date.parse(dtTmp) + (86400000 * Number));    
  
        case 'w' :return new Date(Date.parse(dtTmp) + ((86400000 * 7) * Number));    
  
        case 'q' :return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number*3, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());    
  
        case 'm' :return new Date(dtTmp.getFullYear(), (dtTmp.getMonth()) + Number, dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());    
  
        case 'y' :return new Date((dtTmp.getFullYear() + Number), dtTmp.getMonth(), dtTmp.getDate(), dtTmp.getHours(), dtTmp.getMinutes(), dtTmp.getSeconds());    
  
    }    
  }